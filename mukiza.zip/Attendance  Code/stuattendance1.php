<?php 
@require_once 'config/config.php';
require_once 'config/session.php'; 
require_once 'class/dbclass.php';
require_once 'class/Attandanse.php';
$att = new Attandanse();
$empList = $att->getEmployeeList();
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
    <head>
        <?php require_once 'config/commonJS.php'; ?>
        <script>
            $(document).ready(function(){
                $( "#startDate , #endDate" ).datepicker({
                    dateFormat: 'yy-mm-dd',
                    showOn: "button",
                    buttonImage: "images/calendar.gif",
                    buttonImageOnly: true
                });
            });
        </script>
        <script type="text/javascript">
            function setData(){
                if(!$('#formSubmit').validationEngine('validate')){
                    
                }else{
                    $.ajax({
                        type: "POST",  
                        url: "process/processEmpAttendance.php",
                        data: $('#formSubmit').serialize(),
                        beforeSend : function () {
                            $('#wait').html("Loading");
                        },
                        success: function(resp){
                            $('#AttendanceList').html(resp);
                        },
                        error: function(e){
                        }
                    });
                }
            }
            function ReportType(){
                var res = $('input:radio[name=reportType]:checked').val();
                if(res == 'Salary'){
                    $('.DateHide').hide();
                }else{
                    $('.DateHide').show();
                }
                $('#AttendanceList').html("");
            }
        </script>
        <script>
            window.onload = menuSelect('menuEmployeeReport');
        </script>
    </head>
    <body>
        <!-- wrap starts here -->
        <div id="wrap">

            <!--header -->
            <?php @require_once 'menu/header1.php'; ?>

            <!-- navigation -->	
            <?php @require_once 'menu/menu1.php'; ?>

            <!-- content-wrap starts here -->
            <div id="content-wrap">
                <div id="main">			

                        <div style="float: left;margin: 20px;">

				
				

                  <form id="formSubmit" method="post"  action="">
                        <input type="hidden" name="type" value="EmpView" />
                        <table class="tbl">            
                        	<tr class="DateHide">
                        		<td>
                        			Start Date:
                        		</td>
                        		<td>
                        			<input type="text" class="validate[required]" readonly name="startDate" id="startDate" />
                        		</td>
                        	</tr>
                        	
                        	<tr>
                        		<td colspan="2"><input class="button" type="submit" name="view" value="View" /> </td>
                        	</tr>
                        </table>
                        
                    </form>
                    <table id="AttendanceList" class='tbl' width="700px">
                             <tr><th><b>StudentID</b></th><th><b>Names</b></th><th><b>Subject</b></th> <th> Class</th><th><b>Status</b></th> <th> Date</th></tr>
                         <?php		
						 if(isset($_POST['view'])){
								$con = mysql_connect("localhost", "root" , "");
							$db =mysql_select_db("attendance_system");
								$newsatff='';
						$date =$_POST['startDate'];
						$tea = $_SESSION['UserID'];
								
								$contri=mysql_query("select * from attendance_student where `date` = '$date' AND Teacher = '$tea'");
				if(!$contri){
				echo'hey'.die(mysql_error());

				}						 
							while($row=mysql_fetch_array($contri))
				{
				$newsatff=$row['id'];
				
				     echo "<tr>";
                     echo "<td>". $row['StuID']." </td>";
                     echo "<td><label class='label label-info'>".$row['Names']."</label></td>";
                     echo "<td><label class='label label-info'>".$row['subject']."</label></td>";
					 echo "<td><label class='label label-info'>".$row['class']."</label></td>";
                     echo "<td><label class='label label-info'>".$row['Status']."</label></td>";
					 echo "<td><label class='label label-info'>".$row['date']."</label></td>";
                     echo "</tr>";
				

				}
				}
				?>
                    </table>   
                    <div class="clear"></div>
					<a href="javascript:window.print()">Print</a>
                </div>
            <!--?php @require_once 'menu/sidemenu.php'; ?>	
            <!-- content-wrap ends here -->
            </div>
            <!--footer starts here-->
            <?php @require_once 'menu/footer.php'; ?>
            <!-- wrap ends here -->
        </div>
    </body>
</html>
