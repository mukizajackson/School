<html>
<head>
</head>
<body>

<?php
require_once 'config/config.php';
require_once 'config/session.php';
require_once 'class/dbclass.php';
//$id=$_GET['id'];
// echo"<SCRIPT LANGUAGE='JavaScript'>alert('ID got done".$id."')</script>";
 if(isset($_GET['id']))
{
	$gew = '';
	$id=$_GET['id'];
					$con = mysql_connect("localhost", "root" , "");
							$db =mysql_select_db("attendance_system");
$ccus=mysql_query("select * from student where id = '$id'");
while($row=mysql_fetch_array($ccus))
{

$gew = $row['name'];

}
$staff= '';
$staff = $_SESSION['UserID'];
$ccus=mysql_query("select * from employee_detail where EmpID = '$staff'");
while($row=mysql_fetch_array($ccus))
{

$a=$row['EmpTechnology'];
$b=$row['EmpClass'];
$c=$row['Time'];
}
					            $id        = $_GET['id'];
					            $names     =$_POST['studentnames'];
								$present   = "present";
								$date      = date('Y-m-d');
								$tea = $_SESSION['UserID'];
								//$a = $_POST['stusubject'];
								//$b= $_POST['stuclass'];
								//$c = $_POST['Stutime'];
							 $qry = "INSERT INTO `attendance_student` (`StuID`,`Names`,`Status`,`date`,`Teacher`,`class`,`subject`,`Time`) 
							 VALUES('$id','$gew','$present','$date','$tea','$b','$a','$c') ";
							  echo $sql;
							 //$sample = $sql;
							  //echo"<SCRIPT LANGUAGE='JavaScript'>alert('".$sample."')</script>";
							  echo $sql;
							 $entered = mysql_query($qry) or die("hhhh".mysql_error());
							 if ($entered)
							 {
								 $que="UPDATE `attendance_student` SET `class` ='$b', `subject`='$a', `Time`='$c' WHERE `StuID` ='$id' date = $date";
//echo $que;
  $updatequery = mysql_query($que);
								 echo"<SCRIPT LANGUAGE='JavaScript'>alert('sucessfully done".$sample."')</script>";
								 header("Location:AddAttendanceStudent1.php");
							 }
					
					//echo"<SCRIPT LANGUAGE='JavaScript'>alert('THis student is present')</script>";
					   
				
}
?>
</body>
</html>