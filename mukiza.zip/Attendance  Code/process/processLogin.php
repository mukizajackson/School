<?php
require_once '../config/config.php';
require_once '../class/dbclass.php';
require_once "../class/User.php";

$user = new User();

if($_POST['type']=='login'){
	if($user->login()){
			$SQL = "SELECT * FROM user";
	$result = mysql_query($SQL);
	while ($db_field = mysql_fetch_assoc($result)) {
			$pos = $db_field['duty'];
		    if($pos == "Admin"){
				session_start();
				//$_SESSION['id'] = $user;
				//$_SESSION['start'] = time();// Taking now logged in time.
            	//mysql_close($db_handle);
				header("Location: Admin.php");
				break;
			}
			else if($pos == "Teacher"){
				session_start();
				//$_SESSION['id'] = $user;
				//$_SESSION['client'] = "log";
				///mysql_close($db_handle);
				header("Location: index.php");
				break;
			}
		
	}
		
		
		
		
		//header('Location: ../index.php');
	}else{
		$_SESSION['Msg'] = "Inavalid UserName Or Password";
		header('Location: ../index.php');
	}
}
else if($_POST['type']=='register'){
	
}else{
	header('Location : ../login.php');
}
?>