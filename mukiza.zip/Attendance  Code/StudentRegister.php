<?php
require_once 'config/config.php';
require_once 'config/session.php'; 
require_once 'class/dbclass.php';
//require_once 'class/EmpRegister1.php';

//$emp = new EmpRegister();
//$EmpID = $_REQUEST['EmpID'];
//if($EmpID != NULL){
//    $result = $emp->get($EmpID);
//    if($result == NULL){
//        $EmpID = '';
 //   }
//}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
    <head>
        <?php require_once 'config/commonJS.php'; ?>
        <script>
             $(document).ready(function(){
                   $( "#EmpBirthdate" ).datepicker({
                        dateFormat: 'yy-mm-dd',
                        showOn: "button",
			buttonImage: "images/calendar.gif",
			buttonImageOnly: true,
                        changeMonth: true,
                        changeYear: true,
                        yearRange: "-30"
                   });
              });
        </script>
        <script>
            window.onload = menuSelect('menuEmployee');
        </script>
    </head>

    <body>
        <!-- wrap starts here -->
        <div id="wrap">

            <!--header -->
            <?php @require_once 'menu/header.php'; ?>

            <!-- navigation -->	
            <?php @require_once 'menu/menu.php'; ?>

            <!-- content-wrap starts here -->
            <div id="content-wrap">
			               <div id="main">	
                        <br>			
						<?php
$message='';
$newsatff='';
$newpass ='';

//include'connection.php';
$con = mysqli_connect("localhost", "root" , "") or die(''.mysql_error());
$red= mysqli_select_db($con,"attendance_system") or die();
//$kame= mysql_insert_id($GOO);
$EmpEmail=$_POST['EmpEmail'];
if(isset($_POST['submit'])){
	
$soul=mysqli_query($con,"SELECT * FROM `student` where email='$EmpEmail' ");
if(!$soul){
//echo mysql_error($GOO);	
}
$numrows=mysqli_num_rows($soul);
if($numrows == 0)
{
$user =mysqli_fetch_array($soul);
$EmpName=$_POST['EmpName'];
$EmpAddress=$_POST['EmpAddress'];
//$age=$_POST['age'];
$EmpMobile=$_POST['EmpMobile'];
$EmpEmail=$_POST['EmpEmail'];
$EmpBirthdate=$_POST['EmpBirthdate'];
$daa="INSERT INTO `student` (name,address,mobile,email,dob) 
	Values('$EmpName','$EmpAddress','$EmpMobile','$EmpEmail','$EmpBirthdate')";
$retval = mysqli_query($con,$daa) or die(mysql_query());

$message= "Student Registered Sucessfully";
				
mysqli_close($con);	
	
}
else{
 if($numrows == 1)
{

$message= "Already Exit Try Again";

//header("Location:bus.php?action=199<0");

mysqli_close($con);
}
}
}
?>	
              						
					     <form id="formSubmit" method="post" action=" ">
                        <center>
						 <h3>Student Registration</h3>
						 <?php echo $message; ?>
            <table class="tbl">
                <tr>
                    <td><b>Name</b></td>
                    <td><input type="text" class="validate[required]" name="EmpName" id="EmpName" value="<?php echo $result[0]['EmpName'];?>"/></td>
                </tr>
                <tr>
                    <td><b>Address</b></td>
                    <td><textarea rows="5" cols="30" class="validate[required]" name="EmpAddress" id="EmpAddress" ><?php echo $result[0]['EmpAddress'];?></textarea></td>
                </tr>
                <tr>
                    <td><b>Mobile</b></td>
                    <td><input class="validate[required,minSize[10],maxSize[10],custom[integer]]" type="text" class="validate[required]" name="EmpMobile" id="EmpMobile" value="<?php echo $result[0]['EmpMobile'];?>"/></td>
                </tr>
                <tr>
                    <td><b>Email</b></td>
                    <td><input type="text" class="validate[required,custom[email]]" name="EmpEmail" id="EmpEmail" value="<?php echo $result[0]['EmpEmail'];?>"/></td>
                </tr>
                <tr>
                    <td><b>Birth Date</b></td>
                    <td><input type="text" class="validate[required]" readonly name="EmpBirthdate" id="EmpBirthdate" value="<?php echo $result[0]['EmpBirthdate'];?>"/></td>
                </tr>
                              
                <tr>
                    <td><a href="veiwStudents.php"><input type="button" value="View Students" ></a></td>
                    <td><input type="submit" name="submit" id="" value="<?php echo $EmpID == '' ? 'Register' : 'Update'; ?>"/></td>
                </tr>
            </table>
            </center>
        </form>
					<div class="clear"></div>
         </div>
           	
            <!-- content-wrap ends here -->
            </div>
            <!--footer starts here-->
            <?php @require_once 'menu/footer.php'; ?>
            <!-- wrap ends here -->
        </div>

    </body>
</html>
