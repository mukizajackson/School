<?php
require_once 'config/config.php';
require_once 'config/session.php'; 
require_once 'class/dbclass.php';
//require_once 'class/EmpRegister1.php';

//$emp = new EmpRegister();
//$EmpID = $_REQUEST['EmpID'];
//if($EmpID != NULL){
//    $result = $emp->get($EmpID);
//    if($result == NULL){
//        $EmpID = '';
 //   }
//}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
    <head>
        <?php require_once 'config/commonJS.php'; ?>
        <script>
             $(document).ready(function(){
                   $( "#EmpBirthdate" ).datepicker({
                        dateFormat: 'yy-mm-dd',
                        showOn: "button",
			buttonImage: "images/calendar.gif",
			buttonImageOnly: true,
                        changeMonth: true,
                        changeYear: true,
                        yearRange: "-30"
                   });
              });
        </script>
        <script>
            window.onload = menuSelect('menuEmployee');
        </script>
    </head>

    <body>
        <!-- wrap starts here -->
        <div id="wrap">

            <!--header -->
            <?php @require_once 'menu/header.php'; ?>

            <!-- navigation -->	
            <?php @require_once 'menu/menu.php'; ?>

            <!-- content-wrap starts here -->
            <div id="content-wrap">
			               <div id="main">	
                        <br>
<div style="padding-left:12%;">						
						<?php
$message='';
$newsatff='';
$newpass ='';

//include'connection.php';
$con = mysql_connect("localhost", "root" , "") or die(''.mysql_error());
$red= mysql_select_db("attendance_system") or die();
	
$soul=mysql_query("SELECT * FROM `student`");
echo"<table class=\"table table-bordered table-hover tbl table stripped\" ><tr class='info'> <th>StudentID</th><th>Names</th><th>Address</th><th>Contact</th><th>Email</th><th>BirthDate</th>
<th>Actions</th></tr>";
while($row = mysql_fetch_array($soul))
{
echo "<tr>";
echo "<td>".$row['id']."</td>";
echo "<td>".$row['name']."</td>";
echo "<td>".$row['address']."</td>";
echo "<td>".$row['mobile']."</td>";
echo "<td>".$row['email']."</td>";
echo "<td>".$row['dob']."</td>";
echo '<td><a href="EditDeleteStudent.php?id='.$row['id'].'"><span class="glyphicon glyphicon-filter"></span> Action</a></td>';
echo"</tr>";

}
echo"</tr></table>";

				
mysql_close($con);	

?>		</div>			
					<div class="clear"></div>
         </div>
           	
            <!-- content-wrap ends here -->
            </div>
            <!--footer starts here-->
            <?php @require_once 'menu/footer.php'; ?>
            <!-- wrap ends here -->
        </div>

    </body>
</html>
