<?php
session_start();
?>
<?php
$user = "";
$pass = "";
$msg = "";
 
include('sql.php');

if (isset($_POST['submit'])){
/* 	include 'sql.php'; */

	$user = $_POST['UserName'];
	$pass = $_POST['Password'];
		
	//unwanted HTML (scripting attacks)
	$user = htmlspecialchars($user);
	$pass = htmlspecialchars($pass);
	
	$SQL = "SELECT * FROM `employee_detail` WHERE `EmpID`='$user' AND `Password`='$pass' ";
	$result = mysqli_query($db_handle,$SQL) or mysqli_error();
	while ($db_field = mysqli_fetch_assoc($result)) {
		$a = $db_field['EmpID'];
		$b = $db_field['Password'];
		$pos = $db_field['Role'];
		if(($user == $a) AND ($pass == $b)){
			if($pos == "Admin"){
				session_start();
				$_SESSION['UserID'] = $a;
				//$_SESSION['UserID'] = "log";
				mysqli_close($db_handle);
				header("Location: Admin.php");
				break;
			}
			else if($pos == "Teacher"){
				session_start();
				$_SESSION['UserID'] = $a;
				//$_SESSION['UserID'] = "log";
				mysqli_close($db_handle);
				header("Location: Teacher.php");
				break;
			}
		}
	}
	$msg = "Check username and/or password.";
	mysqli_close($db_handle);
}
?>


<style type="text/css">
	div.sidebar-nav{
		max-width: 250px;
	}
	
</style>
 <?php @require_once 'config/commonJS.php'; ?>	
   <div id="wrap">
            <!--header -->
            <?php //@require_once 'menu/header.php'; ?>
			<link rel="stylesheet" href="css/bootstrap.min.css" />
            <div id="header">
                <h1 id="logo-text"><a href=".">St Paul Primary</a></h1>
                <p id="slogan">School</p>
                <div id="header-links">
                </div>
            </div>
<div class="container" style="margin-top:100px;">
<div class="row">


<div class="container-fluid">


<div class="container-fluid col-sm-5 col-xs-12 col-md-4 col-lg-5 center col-sm-offset-4">
<div class="panel panel-primary">
	<div class="panel-heading">

		<div class="panel-title">
				
		</div>
	</div>
	<div class="panel-body">
	<h4 class="text-primary">Please sign in</h4>
	<?php if ($msg) {
		echo '<div class="alert alert-danger">'.$msg.'</div>';
		# code...
	} ?>
		  <form id="formSubmit" method="post" class="form-horizontal" action="">
				
                    <input type="hidden" name="type" value="login" />
                    <table class="tbl"  class="table table-responsive">
                        <tr>
                            <td>StaffID</td>
                            <td><input type="text" id="UserName" class="form-control validate[required]" name="UserName" /></td>
                        </tr>
                        <tr>
                            <td>Password</td>
                            <td><input type="password" id="Password" class=" form-control validate[required]" name="Password" /></td>
                        </tr>
                        <tr>
                            <td><input type="submit" class="btn btn-info" value="Login" name="submit" /></td>
                        </tr>
                    </table>
                    </form>
	</div>

 </div>

</div>


<!-- <img src = "images/image002.gif"></img>
 -->

</div><!-- end container-fluid  -->
</div><!-- div.row -->
</div><!-- end coatainer-->
</div>
            <!-- wrap ends here -->
</body>
</html>
