<?php
	
	if($_SESSION['UserID']==NULL){
		header('Location: index.php');
	}
?>