<?php

class EmpRegister extends MySQLCN {

    function Add() {
        $qry = "INSERT INTO `employee_detail` 
            ( `EmpName`, `EmpAddress`, `EmpMobile`, 
              `EmpEmail`, `EmpBirthdate`, `EmpBloodGroup`, `EmpTechnology`) 
            VALUES 
            ( '{$_POST['EmpName']}', '{$_POST['EmpAddress']}', '{$_POST['EmpMobile']}', 
              '{$_POST['EmpEmail']}', '{$_POST['EmpBirthdate']}', '{$_POST['EmpBloodGroup']}', '{$_POST['EmpTechnology']}')";
        return $this->insert($qry);
    }



    function Delete($id) {
        $qry = "DELETE FROM `employee_detail` WHERE EmpID = '{$id}'";
        return $this->insert($qry);
    }

    function get($id) {
        $qry = "SELECT * 
                FROM `employee_detail` ed LEFT JOIN salary_detail sd ON sd.EmpID = ed.EmpID
                WHERE ed.EmpID = '{$EmpID}'";
        return $this->select($qry);
    }

    function SalaryAdd() {
        $result = $this->get($_POST['EmpID']);
        if ($result == NULL) {
            return false;
        }

        $dateOneMonthAdded = strtotime(date("Y-m-d", strtotime($_POST['LastIncrement'])) . "+{$_POST['IncrementAfter']} month");
        $IncrementDate = date('Y-m-d', $dateOneMonthAdded);
        
        $lastt = strtotime(date("Y-m-d", strtotime($_POST['LastIncrement'])));
        $LastIncrement = date('Y-m-01', $lastt);
        
        $qry = "INSERT INTO `salary_detail` 
               (`EmpID`,`JoinDate`,`EmpType`,
                `CurrentSalary`,`IncrementAmount`,`IncrementAfter`,`IncrementDate`,
                `LastSalary`,`LastIncrement`
               )
               VALUES 
               (
                '{$_POST['EmpID']}','{$_POST['JoinDate']}','{$_POST['EmpType']}',
                '{$_POST['CurrentSalary']}','{$_POST['IncrementAmount']}','{$_POST['IncrementAfter']}','{$IncrementDate}',
                '{$_POST['CurrentSalary']}','{$LastIncrement}'
               )
               ";
        $this->insert($qry);
    }

 
    
    function SalaryDelete($EmpID){
        $qry = "DELETE FROM `salary_detail` WHERE id = '{$id}'";
        return $this->insert($qry);
    }



	    function student() {
        $cvmo = "SELECT *
                FROM `student` ORDER BY `name` ";
        return $this->select($cvmo);
    }
    
}

?>