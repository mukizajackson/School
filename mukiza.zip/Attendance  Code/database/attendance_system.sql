-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 05, 2020 at 10:42 PM
-- Server version: 10.1.24-MariaDB
-- PHP Version: 7.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `attendance_system`
--

-- --------------------------------------------------------

--
-- Table structure for table `attendance`
--

CREATE TABLE `attendance` (
  `AttID` int(20) NOT NULL,
  `EmpID` int(10) NOT NULL,
  `Prensent` int(1) NOT NULL,
  `AttDate` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `attendance`
--

INSERT INTO `attendance` (`AttID`, `EmpID`, `Prensent`, `AttDate`) VALUES
(1495, 23, 1, '2013-05-23'),
(1497, 24, 1, '2017-05-05'),
(1498, 24, 1, '2017-05-06'),
(1499, 23, 1, '2017-05-22'),
(1500, 24, 1, '2017-05-22'),
(1501, 24, 1, '2017-05-31');

-- --------------------------------------------------------

--
-- Table structure for table `attendance_student`
--

CREATE TABLE `attendance_student` (
  `asID` int(10) NOT NULL,
  `StuID` int(34) NOT NULL,
  `Names` varchar(230) NOT NULL,
  `Status` varchar(12) NOT NULL,
  `date` date NOT NULL,
  `Teacher` varchar(22) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `attendance_student`
--

INSERT INTO `attendance_student` (`asID`, `StuID`, `Names`, `Status`, `date`, `Teacher`) VALUES
(44, 134437, 'Vandam', 'present', '2017-06-19', '24'),
(43, 134438, 'Peter', 'present', '2017-06-19', '24'),
(42, 134436, 'kamoga charlse', 'present', '2017-06-19', '24'),
(41, 134435, 'sakaka', 'present', '2017-06-19', '24'),
(40, 134436, 'kamoga charlse', 'present', '2017-06-19', '24'),
(39, 134435, 'sakaka', 'present', '2017-06-17', '23'),
(38, 134436, 'kamoga charlse', 'present', '2017-06-17', '24'),
(45, 134445, 'aaa', 'present', '2020-04-27', '23'),
(46, 134445, 'aaa', 'present', '2020-04-27', ''),
(47, 134444, 'Asak', 'present', '2020-04-27', '');

-- --------------------------------------------------------

--
-- Table structure for table `employee_detail`
--

CREATE TABLE `employee_detail` (
  `EmpID` int(10) NOT NULL,
  `EmpName` varchar(255) NOT NULL,
  `EmpAddress` text NOT NULL,
  `EmpMobile` varchar(15) NOT NULL,
  `EmpEmail` varchar(50) NOT NULL,
  `EmpBirthdate` date NOT NULL,
  `EmpBloodGroup` varchar(5) NOT NULL,
  `EmpTechnology` varchar(20) NOT NULL,
  `Role` varchar(12) NOT NULL,
  `EmpClass` varchar(4) NOT NULL,
  `Password` varchar(120) NOT NULL,
  `Time` time NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `employee_detail`
--

INSERT INTO `employee_detail` (`EmpID`, `EmpName`, `EmpAddress`, `EmpMobile`, `EmpEmail`, `EmpBirthdate`, `EmpBloodGroup`, `EmpTechnology`, `Role`, `EmpClass`, `Password`, `Time`) VALUES
(23, 'jayvik kashipara', 'rajkot', '9426666226', 'info@kashipara.in', '2013-05-23', 'A+', 'SST', 'Admin', '', 'admin', '00:00:00'),
(24, 'Kaka Ali', 'kakeka', '0789918188', 'kaka@gmail.com', '1989-10-10', 'A+', 'English', 'Teacher', '', 'kasato', '00:00:00'),
(25, 'Kato', 'Mengo', '0721817231', 'kato@yahoo.com', '1993-07-15', 'B+', 'Mathematics', 'Teacher', '', '', '00:00:00'),
(26, 'man', 'mengo', '0703660227', 'ka@gmail.com', '2020-04-01', 'O+', 'English', 'Teacher', 'P2', 'qwerty', '00:00:04');

-- --------------------------------------------------------

--
-- Table structure for table `increment_detail`
--

CREATE TABLE `increment_detail` (
  `IncID` int(20) NOT NULL,
  `EmpID` int(20) NOT NULL,
  `Salary` int(20) NOT NULL,
  `IncrementDate` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `increment_detail`
--

INSERT INTO `increment_detail` (`IncID`, `EmpID`, `Salary`, `IncrementDate`) VALUES
(1, 24, 600000, '2012-10-01'),
(2, 25, 233000, '2017-07-12'),
(3, 24, 607000, '2013-03-01'),
(4, 24, 614000, '2013-08-01');

-- --------------------------------------------------------

--
-- Table structure for table `salary_detail`
--

CREATE TABLE `salary_detail` (
  `SalaryID` int(20) NOT NULL,
  `EmpID` int(20) NOT NULL,
  `JoinDate` date NOT NULL,
  `EmpType` varchar(20) NOT NULL,
  `CurrentSalary` int(10) NOT NULL,
  `IncrementAmount` int(10) NOT NULL,
  `IncrementAfter` int(5) NOT NULL,
  `IncrementDate` date NOT NULL,
  `LastSalary` int(10) NOT NULL,
  `LastIncrement` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `salary_detail`
--

INSERT INTO `salary_detail` (`SalaryID`, `EmpID`, `JoinDate`, `EmpType`, `CurrentSalary`, `IncrementAmount`, `IncrementAfter`, `IncrementDate`, `LastSalary`, `LastIncrement`) VALUES
(1, 24, '2005-07-06', 'employee', 621000, 7000, 5, '2014-01-01', 614000, '2013-08-01'),
(3, 23, '2017-01-04', 'employee', 500000, 600000, 5, '2017-11-01', 500000, '2017-06-01');

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `id` int(10) NOT NULL,
  `name` varchar(60) NOT NULL,
  `address` varchar(12) NOT NULL,
  `mobile` int(13) NOT NULL,
  `email` varchar(39) NOT NULL,
  `dob` date NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`id`, `name`, `address`, `mobile`, `email`, `dob`) VALUES
(134435, 'sakaka', 'hhhh', 976523232, 'ddd@gmail.com', '1989-11-25'),
(134436, 'kamoga charlse', 'sonde', 2147483647, 'dnnn@gmail.com', '1992-02-14'),
(134437, 'Vandam', 'Gomba', 999992122, 'van@yahoo.com', '1993-01-14'),
(134439, 'Peter', 'Masaka', 708123456, 'peter12@yahoo.com', '1989-11-17'),
(134442, 'Pual', 'kakeka', 379992999, 'paul@gmail.com', '1990-07-12'),
(134443, 'Pual', 'kakeka', 379992999, 'paul@gmail.com', '1990-07-12'),
(134444, 'Asak', 'kamapla', 2147483647, 'asak@hotmail.com', '1991-06-11'),
(134445, 'aaa', 'aaaaa', 2147483647, 'ka@gmail.com', '1993-04-26');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `UserID` int(10) NOT NULL,
  `UserName` varchar(50) NOT NULL,
  `Password` varchar(50) NOT NULL,
  `Role` varchar(45) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`UserID`, `UserName`, `Password`, `Role`) VALUES
(2, 'admin', 'admin', 'Admin'),
(3, 'Kasato', 'kasato', 'Teacher');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `attendance`
--
ALTER TABLE `attendance`
  ADD PRIMARY KEY (`AttID`),
  ADD KEY `EmpID` (`EmpID`);

--
-- Indexes for table `attendance_student`
--
ALTER TABLE `attendance_student`
  ADD PRIMARY KEY (`asID`);

--
-- Indexes for table `employee_detail`
--
ALTER TABLE `employee_detail`
  ADD PRIMARY KEY (`EmpID`);

--
-- Indexes for table `increment_detail`
--
ALTER TABLE `increment_detail`
  ADD PRIMARY KEY (`IncID`),
  ADD KEY `EmpID` (`EmpID`),
  ADD KEY `EmpID_2` (`EmpID`);

--
-- Indexes for table `salary_detail`
--
ALTER TABLE `salary_detail`
  ADD PRIMARY KEY (`SalaryID`),
  ADD KEY `EmpID` (`EmpID`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`UserID`),
  ADD KEY `UserID` (`UserID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `attendance`
--
ALTER TABLE `attendance`
  MODIFY `AttID` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1502;
--
-- AUTO_INCREMENT for table `attendance_student`
--
ALTER TABLE `attendance_student`
  MODIFY `asID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=48;
--
-- AUTO_INCREMENT for table `employee_detail`
--
ALTER TABLE `employee_detail`
  MODIFY `EmpID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;
--
-- AUTO_INCREMENT for table `increment_detail`
--
ALTER TABLE `increment_detail`
  MODIFY `IncID` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `salary_detail`
--
ALTER TABLE `salary_detail`
  MODIFY `SalaryID` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `student`
--
ALTER TABLE `student`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=134446;
--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `UserID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `attendance`
--
ALTER TABLE `attendance`
  ADD CONSTRAINT `attendance_ibfk_1` FOREIGN KEY (`EmpID`) REFERENCES `employee_detail` (`EmpID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `increment_detail`
--
ALTER TABLE `increment_detail`
  ADD CONSTRAINT `increment_detail_ibfk_1` FOREIGN KEY (`EmpID`) REFERENCES `employee_detail` (`EmpID`) ON DELETE CASCADE;

--
-- Constraints for table `salary_detail`
--
ALTER TABLE `salary_detail`
  ADD CONSTRAINT `salary_detail_ibfk_1` FOREIGN KEY (`EmpID`) REFERENCES `employee_detail` (`EmpID`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
