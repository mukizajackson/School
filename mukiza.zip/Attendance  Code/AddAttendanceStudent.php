<?php
require_once 'config/config.php';
require_once 'config/session.php';
require_once 'class/dbclass.php';
require_once 'studentver.php';
//require_once 'class/EmpRegister2.php';
//$emp = new EmpRegister();
//$student = $emp->student();
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
    <head>

        <?php require_once 'config/commonJS.php'; ?>
        <script>
            $(document).ready(function(){
                $( "#date" ).datepicker({
                    currentText: "Now",
                    dateFormat: 'yy-mm-dd',
                    inline: true,
                    altField: '#datepicker_value',
                    onSelect: function(){
                        getData();
                    }
                    
                });
                var myDate = new Date();
                var prettyDate =myDate.getFullYear() +'-' + (myDate.getMonth()+1) + '-' + myDate.getDate();
                $("#datepicker_value").val(prettyDate);
            });
            
        </script>
        <!--script type="text/javascript">
        	function getData(){
                var dt = $("#datepicker_value").val();
            	$.ajax({
                    type: "POST",
                    url: "process/processEmpAttendance.php",
                    data: {type:'get',date:dt},
                    beforeSend : function () {
                        $('#wait').html("Loading");
                    },
                    success: function(resp){
                    	var obj = jQuery.parseJSON(resp);
                    	if(obj.sucess == 'new'){
                    		$('.present').attr('checked',true);	
                    	}else{
                    		$('.present').attr('checked',false);
                    		$(obj.data).attr('checked',true);
                    	}
                    },
                    error: function(e){
                        alet('Please Try again form not submit sucessful');
                    }
                });
        	}	
           /// function setData(){
            //    if(!$('#formSubmit').validationEngine('validate')){

             //   }else{
             //       var absent = unCheckedEmployee();
             //       var formVal = $('#formSubmit').serialize();
             //       if(absent != null){
             //           formVal+="&absent="+absent;
             //       }
              //      $.ajax({
               //         type: "POST",
                 //       url: "process/processEmpAttendance1.php",
                   //     data: formVal,
                     //   beforeSend : function () {
                       //     $('#wait').html("Loading");
                    //    },
                  //      success: function(resp){
                  //          alert('Sucessful'+resp);
                  //      },
                  //      error: function(e){
                 //           alet('Please Try again form not submit sucessful');
                 //       }
                 //   });
                //}
            //}
            function unCheckedEmployee(){
                    var ellength = document.formSubmit.elements.length;
                    var absent = new Array();
                    for(i=0;i<ellength;i++){
                          var type = document.formSubmit.elements[i].type;
                          var name = document.formSubmit.elements[i].name;
                          if (type=="checkbox" && name=="present[]" && document.formSubmit.elements[i].checked){
                          }
                          else if(type=="checkbox" && name=="present[]"){
                              absent.push(document.formSubmit.elements[i].value);
                          }
                    }
                    return absent;
            }
            
        </script--->
        <script>
        $(document).ready(function(){
        	window.onload = menuSelect('menuAttandance');
            window.onload = getData();
        });
            
        </script>
        
    </head>

    <body>
        <!-- wrap starts here -->
        <div id="wrap">

            <!--header -->
            <?php @require_once 'menu/header.php'; ?>

            <!-- navigation -->	
            <?php @require_once 'menu/menu.php'; ?>

            <!-- content-wrap starts here -->
            <div id="content-wrap">
                <div id="main">				
                    
                                      <form class='form'  method="post" action="" >
									  <?  echo $sample;?>
                        <!--input type="hidden" name="type" value="<!?php echo $id == '' ? 'Add' : 'Update'; ?>">
<!--                        <input type="text" onchange="getData(this.value)" class="validate[required]" readonly style="margin-left: 20px;" name="date" id="date" >-->
                        <!--input type="hidden" onchange="getData(this.value)" class="validate[required]" readonly style="margin-left: 20px;" name="date" id="datepicker_value" -->
                            <div id="date" style="float: right;margin: 20px;"></div>    
                        <br/>
                        <br/>
                        <div style="float: left;margin: 20px;">
									<?php
$message='';
$newsatff='';
$newpass ='';

//include'connection.php';
$con = mysqli_connect("localhost", "root" , "") or die(''.mysql_error());
$red= mysqli_select_db($con,"attendance_system") or die();
	$card = $_SESSION['UserID'];
$soul=mysqli_query($con,"SELECT * FROM `employee_detail` where EmpID = '$card'");

while($row = mysqli_fetch_array($soul))
{
$a=$row['EmpTechnology'];
$b=$row['EmpClass'];
$c=$row['Time'];

}

mysqli_close($con);	

?>
						<table>
						<tr>
						<td>Subject </td><td><input type="text" readonly name="Stusubject"  value="<?php echo $a;?>"/>
						</td>
						<td>Class</td><td> <input type="text" readonly  name="stuclass"  value="<?php echo $b;?>"/>
						</td>
						
						<td>Time</td><td><td><input type="text" readonly name="Stutime"  value="<?php echo $c;?>"/></td>     </td>
						</tr>
						</table>
                        <table width="500px" class="tbl">
                            <tr><th><b>Present</b></th><th><b> StudentID</b></th><th><b>Names</b></th></tr>
                         <?php		
								$con = mysqli_connect("localhost", "root" , "");
							$db =mysqli_select_db($con,"attendance_system");
								$newsatff='';
						
								
								$contri=mysqli_query($con,"select * from student order by name asc");
				if(!$contri){
				echo'hey'.die(mysqli_error());

				}						 
							while($row=mysqli_fetch_array($contri))
				{
				$newsatff=$row['id'];
				
				     echo "<tr>";
                     echo "<td>
					 <input type='hidden' name='type' value='<!?php echo $id ?>'>
					<a href='studentver.php?id=".$row['id']."'> <input  type='button' name='press' value='Present'></a>
					<input  type='submit' name='apress' value='Absent'></td>";
                     echo "<td><label class='label label-info' name='studid'>".$row['id']."</label></td>";
                     echo "<td>
					 <input type='text' name='studentnames' readonly='readonly' value=".$row['name'].">
					</td>";
                     echo "</tr>";
				

				}
				
				$sample = '';
				
				if(isset($_POST['apress'])){
					echo"<SCRIPT LANGUAGE='JavaScript'>alert('THis student is nit present')</script>";
				}
				
				?>
				
			
				
</table>
                  
                        </div>    
                    </form>
                    <div class="clear"></div>
                </div>	
                <!-- content-wrap ends here -->	
            </div>

            <!--footer starts here-->
            <?php @require_once 'menu/footer.php'; ?>

            <!-- wrap ends here -->
        </div>

    </body>
</html>
