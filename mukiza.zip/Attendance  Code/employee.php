<?php
require_once 'config/config.php';
require_once 'config/session.php'; 
require_once 'class/dbclass.php';
//require_once 'class/EmpRegister1.php';

//$emp = new EmpRegister();
//$EmpID = $_REQUEST['EmpID'];
//if($EmpID != NULL){
//    $result = $emp->get($EmpID);
//    if($result == NULL){
//        $EmpID = '';
 //   }
//}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
    <head>
        <?php require_once 'config/commonJS.php'; ?>
        <script>
             $(document).ready(function(){
                   $( "#EmpBirthdate" ).datepicker({
                        dateFormat: 'yy-mm-dd',
                        showOn: "button",
			buttonImage: "images/calendar.gif",
			buttonImageOnly: true,
                        changeMonth: true,
                        changeYear: true,
                        yearRange: "-30"
                   });
              });
        </script>
        <script>
            window.onload = menuSelect('menuEmployee');
        </script>
    </head>

    <body>
        <!-- wrap starts here -->
        <div id="wrap">
<?php
//include'connection.php';
$con = mysqli_connect("localhost", "root" , "") or die(''.mysql_error());
$red= mysqli_select_db($con, "attendance_system") or die();

 if (isset($_POST['up']))
{
$id=$_GET['solid'];
$Code=$_POST['stunames'];
$Interest=$_POST['address'];
$AmountPaid=$_POST['mobile'];
$Balance=$_POST['email'];
$Date=$_POST['dob'];

//$blood=$_POST['address'];
$tech=$_POST['subject'];
$class=$_POST['teaclass'];
$tym=$_POST['time'];
// Edit the data
$sql="UPDATE `employee_detail` SET 

 `EmpName`='$Code', 
`EmpAddress`='$Interest',
 `EmpMobile`='$AmountPaid',
  EmpEmail='$Balance',
  `EmpBirthdate`='$Date',
 `EmpTechnology`='$tech',
  EmpClass='$class',
  `Time`='$tym'
  WHERE EmpID ='$id'";
echo $sql;
  $updatequery = mysqli_query($con, $sql);
   
  if(!$updatequery)  {
	  $message='Error updating database'.die("Error updating database");
	  //header("Location:editpayment.php");
  }else{
		$message= 'The data has updated successfully.';
		header("Location:EmployeeList.php");
	}
}

?>

<?php
if (isset($_POST['CDus']))
{
$id=$_GET['solid'];
$sql="DELETE from `student`  WHERE EmpID ='".$id."'";
  $updatequery = mysqli_query( $sql,$con);
  
  if(!$updatequery)  {
	  $message=("Error deleting data from database database");
  }else{
	     header("Location:EmployeeList.php");
		$message= 'The data has been deleted  successfully.';
	}
}
?>
            <!--header -->
            <?php @require_once 'menu/header.php'; ?>

            <!-- navigation -->	
            <?php @require_once 'menu/menu.php'; ?>

            <!-- content-wrap starts here -->
            <div id="content-wrap">
			               <div id="main">	
                        <br>
<div style="padding-left:12%;">		
<?php echo $message; ?>				
<?php
 $password="password";
 if(isset($_GET['solid']))
 {
	 
	 $id=$_GET['solid'];
	 $qry=mysqli_query($con,"SELECT * FROM `employee_detail` WHERE EmpID='$id'");
	 if(!$qry)
	 {
	 die("Query Failed: ". mysqli_error());
	 }else{
		 echo'<div class="container col-sm-10"><form action="" class="form-horizontal" role="form" method="post"> ';
		/* Fetching data from the field "Email" */
	 while($row=mysqli_fetch_array($qry))
	 { 
	 
	 
echo'
<div class="form-group" >
<label class="control-label col-sm-2" for="Member ID">EmpID:</label>
 <div class="col-lg-10"><input type="text" class="form-control" readonly="readonly  id="studentid"  name="member"  value="'.$row['EmpID'].'" />
 </div></div>';

 echo'<div class="form-group" >
 <label class="control-label col-sm-2" for="Instalement">Names:</label>
 <div class="col-lg-10">
 <input type="text" class="form-control" id="fn"  name="stunames"  value="'.$row['EmpName'].'" />
 </div></div>';
  
echo'<div class="form-group" >
<label class="control-label col-sm-2" for="Instalement">Address:</label>
 <div class="col-lg-10"><input type="text" class="form-control" id="fn"  name="address"  value="'.$row['EmpAddress'].'" />
 </div></div>';
 
 echo'<div class="form-group" >
 <label class="control-label col-sm-2" for="Instalement">Mobile:</label>
 <div class="col-lg-10"><input type="text" class="form-control" id="fn"  name="mobile"  value="'.$row['EmpMobile'].'" />
 </div></div>';
 
 echo'<div class="form-group" >
 <label class="control-label col-sm-2" for="Instalement">Email:</label>
 <div class="col-lg-10"><input type="text" class="form-control" id="fn"  name="email"  value="'.$row['EmpEmail'].'" />
 </div></div>';
  echo'<div class="form-group" >
 <label class="control-label col-sm-2" for="Instalement">BirthDate:</label>
 <div class="col-lg-10"><input type="text" class="form-control" id="fn"  name="dob"  value="'.$row['EmpBirthdate'].'" />
 </div></div>';
  echo'<div class="form-group" >
 <label class="control-label col-sm-2" for="Instalement">Subject:</label>
 <div class="col-lg-10"><input type="text" class="form-control" id="fn"  name="subject"  value="'.$row['EmpTechnology'].'" />
 </div></div>';
 
 echo'<div class="form-group" >
 <label class="control-label col-sm-2" for="Instalement">Class:</label>
 <div class="col-lg-10"><input type="text" class="form-control" id="fn"  name="teaclass"  value="'.$row['EmpClass'].'" />
 </div></div>';
  echo'<div class="form-group" >
 <label class="control-label col-sm-2" for="Instalement">Time:</label>
 <div class="col-lg-10"><input type="text" class="form-control" id="fn"  name="time"  value="'.$row['Time'].'" />
 </div></div>';
  echo'
   <div class="form-group col-sm-10">        
      <div class=" text-right col-sm-4">
        <button type="submit" class="btn btn-success" name="up">Update Data</button>
       
      </div>
            
      <div class="col-sm-1">
        <button type="submit" class="btn btn-info" name="CDus">Delete Data</button>
      </div>';
	 }
	 echo'</div></form>';
	 }
 }

 ?></div></div>
 

	</div>			
					<div class="clear"></div>
         </div>
           	
            <!-- content-wrap ends here -->
            </div>
            <!--footer starts here-->
            <?php @require_once 'menu/footer.php'; ?>
            <!-- wrap ends here -->
        </div>

    </body>
</html>
