<?php
require_once 'config/config.php';
require_once 'config/session.php'; 
require_once 'class/dbclass.php';
//require_once 'class/EmpRegister.php';

//$emp = new EmpRegister();
//$EmpID = $_REQUEST['EmpID'];
//if($EmpID != NULL){
//    $result = $emp->get($EmpID);
//    if($result == NULL){
//        $EmpID = '';
//    }
//}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
    <head>
        <?php require_once 'config/commonJS.php'; ?>
        <script>
             $(document).ready(function(){
                   $( "#EmpBirthdate" ).datepicker({
                        dateFormat: 'yy-mm-dd',
                        showOn: "button",
			buttonImage: "images/calendar.gif",
			buttonImageOnly: true,
                        changeMonth: true,
                        changeYear: true,
                        yearRange: "-30"
                   });
              });
        </script>
        <script>
            window.onload = menuSelect('menuEmployee');
        </script>
    </head>

    <body>
	<?php


//include'connection.php';
$con = mysqli_connect("localhost", "root" , "") or die(''.mysql_error());
$red= mysqli_select_db($con, "attendance_system") or die();
//$kame= mysql_insert_id($GOO);
$EmpEmail=$_POST['EmpEmail'];
if(isset($_POST['submit'])){
	
$soul=mysqli_query($con,"SELECT * FROM `employee_detail` where EmpEmail ='$EmpEmail' ");
if(!$soul){
//echo mysqli_error($GOO);	
}
$numrows=mysqli_num_rows($soul);
if($numrows == 0)
{
$user =mysqli_fetch_array($soul);
$EmpName=$_POST['EmpName'];
$EmpAddress=$_POST['EmpAddress'];
$EmpMobile=$_POST['EmpMobile'];
$EmpEmail=$_POST['EmpEmail'];
$EmpBirthdate=$_POST['EmpBirthdate'];
$EmpTechnology=$_POST['EmpTechnology'];
$EmpRole=$_POST['EmpRole'];
$EmpBloodGroup=$_POST['EmpBloodGroup'];
$EmpPassword=$_POST['EmpPassword'];
$EmpTime=$_POST['EmpTime'];
$EmpClass=$_POST['EmpClass'];
$daa="INSERT INTO `employee_detail` (EmpName,EmpAddress,EmpMobile,EmpEmail,EmpBirthdate,EmpBloodGroup,EmpTechnology,Role,Password,EmpClass,Time) 
	Values('$EmpName','$EmpAddress','$EmpMobile','$EmpEmail','$EmpBirthdate','$EmpBloodGroup','$EmpTechnology','$EmpRole','$EmpPassword','$EmpClass','$EmpTime')";
echo $daa;
	$retval = mysqli_query($con,$daa) or die();

$message= "Employee Registered Sucessfully";
				
mysqli_close($con);	
	
}
else{
 if($numrows == 1)
{

$message= "Already Exit Try Again";

//header("Location:bus.php?action=199<0");

mysqli_close($con);
}
}
}
?>
        <!-- wrap starts here -->
        <div id="wrap">

            <!--header -->
            <?php @require_once 'menu/header.php'; ?>

            <!-- navigation -->	
            <?php @require_once 'menu/menu.php'; ?>

            <!-- content-wrap starts here -->
            <div id="content-wrap">
                <div id="main">				
                    <?php echo $message; ?>
                    <form id="formSubmit" method="post" action="">
            <center>
									
			
            <table class="tbl">
                <tr>
                    <td><b>Name</b></td>
                    <td><input type="text" class="validate[required]" name="EmpName" id="EmpName" value="<?php echo $result[0]['EmpName'];?>"/></td>
                </tr>
                <tr>
                    <td><b>Address</b></td>
                    <td><textarea rows="5" cols="30" class="validate[required]" name="EmpAddress" id="EmpAddress" ><?php echo $result[0]['EmpAddress'];?></textarea></td>
                </tr>
                <tr>
                    <td><b>Mobile</b></td>
                    <td><input class="validate[required,minSize[10],maxSize[10],custom[integer]]" type="text" class="validate[required]" name="EmpMobile" id="EmpMobile" value="<?php echo $result[0]['EmpMobile'];?>"/></td>
                </tr>
                <tr>
                    <td><b>Email</b></td>
                    <td><input type="text" class="validate[required,custom[email]]" name="EmpEmail" id="EmpEmail" value="<?php echo $result[0]['EmpEmail'];?>"/></td>
                </tr>
                <tr>
                    <td><b>Birth Date</b></td>
                    <td><input type="text" class="validate[required]" readonly name="EmpBirthdate" id="EmpBirthdate" value="<?php echo $result[0]['EmpBirthdate'];?>"/></td>
                </tr>
				 <tr>
                    <td><b>Class</b></td>
                    <td>
					<select name="EmpClass" id="EmpBloodGroup">
					         <option value=" " <?php echo $result[0]['EmpClass'] == ' ' ? 'selected' : ''; ?> ></option>
                            <option value="P1" <?php echo $result[0]['EmpClass'] == 'P1' ? 'selected' : ''; ?> >P1</option>
                            <option value="P2" <?php echo $result[0]['EmpClass'] == 'P2' ? 'selected' : ''; ?> >P2</option>
                            <option value="P3" <?php echo $result[0]['EmpClass'] == 'P3' ? 'selected' : ''; ?> >P3</option>
                            <option value="P4" <?php echo $result[0]['EmpClass'] == 'P4' ? 'selected' : ''; ?> >P4</option>
                            <option value="P5" <?php echo $result[0]['EmpClass'] == 'P5' ? 'selected' : ''; ?> >P5</option>
                            <option value="P6" <?php echo $result[0]['EmpClass'] == 'P6' ? 'selected' : ''; ?> >P6</option>
                            <option value="P7" <?php echo $result[0]['EmpClass'] == 'P7' ? 'selected' : ''; ?> >P7</option>
                    </select>
					</td>
                </tr>
                <tr>
                    <td><b>Time</b></td>
                    <td><input type="text" class="validate[required]"  name="EmpTime" id="EmpName" value="<?php echo $result[0]['Time'];?>"/></td>
                </tr>
                <tr>
                    <td><b>Blood Group</b></td>
                    <td><select name="EmpBloodGroup" id="EmpBloodGroup">
                            <option value="A+" <?php echo $result[0]['EmpBloodGroup'] == 'A+' ? 'selected' : ''; ?> >A+</option>
                            <option value="A-" <?php echo $result[0]['EmpBloodGroup'] == 'A-' ? 'selected' : ''; ?> >A-</option>
                            <option value="B+" <?php echo $result[0]['EmpBloodGroup'] == 'B+' ? 'selected' : ''; ?> >B+</option>
                            <option value="B-" <?php echo $result[0]['EmpBloodGroup'] == 'B-' ? 'selected' : ''; ?> >B-</option>
                            <option value="AB+" <?php echo $result[0]['EmpBloodGroup'] == 'AB+' ? 'selected' : ''; ?> >AB+</option>
                            <option value="AB-" <?php echo $result[0]['EmpBloodGroup'] == 'AB-' ? 'selected' : ''; ?> >AB-</option>
                            <option value="O+" <?php echo $result[0]['EmpBloodGroup'] == 'O+' ? 'selected' : ''; ?> >O+</option>
                            <option value="O-" <?php echo $result[0]['EmpBloodGroup'] == 'O-' ? 'selected' : ''; ?> >O-</option>
                        </select>
                    </td>
                </tr>
                <tr>
                    <td><b>Technology</b></td>
                    <td>
                        <select name="EmpTechnology" id="EmpTechnology">
						 <option value=" " <?php echo $result[0]['EmpTechnology'] == 'php' ? 'selected' : ''; ?> > </option>
                            <option value="Mathematics" <?php echo $result[0]['EmpTechnology'] == 'php' ? 'selected' : ''; ?> >Mathematics</option>
                            <option value="English" <?php echo $result[0]['EmpTechnology'] == 'android' ? 'selected' : ''; ?> >English</option>
                            <option value="SST" <?php echo $result[0]['EmpTechnology'] == 'iphone' ? 'selected' : ''; ?> >SST </option>
							<option value="Science" <?php echo $result[0]['EmpTechnology'] == 'iphone' ? 'selected' : ''; ?> >Science </option>
                        </select>
                    </td>
                </tr>
				 <tr>
                    <td><b>Role</b></td>
                    <td>
					<select class="validate[required,custom[role]]" name="EmpRole" id="EmpRole" value="<?php echo $result[0]['Role'];?>">
					<option> </option><option>Teacher</option><option>Admin</option>
					</select>
					<!--input type="text" class="validate[required,custom[email]]" name="EmpEmail" id="EmpEmail" value="<!?php echo $result[0]['EmpEmail'];?>"/---></td>
                </tr>
                <tr>
                    <td><b>Password</b></td>
                    <td><input type="password" class="validate[required]" name="EmpPassword" id="EmpName" value="<?php echo $result[0]['Password'];?>""/></td>
                </tr>
                <tr>
                    <td></td>
                    <td><input type="submit" name="submit" id="" value="<?php echo $EmpID == '' ? 'Register' : 'Update'; ?>"/></td>
                </tr>
            </table>
            </center>
        </form>
                    <div class="clear"></div>
         </div>
           
            <!-- content-wrap ends here -->
            </div>
            <!--footer starts here-->
            <?php @require_once 'menu/footer.php'; ?>
            <!-- wrap ends here -->
        </div>

    </body>
</html>
