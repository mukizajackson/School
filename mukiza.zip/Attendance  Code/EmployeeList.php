<?php
require_once 'config/config.php'; 
require_once 'config/session.php';
require_once 'class/dbclass.php';
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
    <head>
        <?php require_once 'config/commonJS.php'; ?>
        <!--script>
           $.fx.speeds._default = 1000;
           $(document).ready(function() {
           var oTable = $('#dataList').dataTable( {
                "bJQueryUI": true,
                "sPaginationType": "full_numbers",
                "bProcessing": true,
                "bServerSide": true,
                "bRedraw" : true,
                "sAjaxSource": "process/employeelData.php",
                "aoColumns": [
                    { "mDataProp": "EmpID" },
                    { "mDataProp": "EmpName" },
                    { "mDataProp": "EmpClass" },
                    { "mDataProp": "EmpTechnology" },
                    { "mDataProp": "Time" },
                    { "mDataProp": "edit" },
                    { "mDataProp": "delete" }
                ],
                "aoColumnDefs": [
                   { "bSortable": false, "aTargets": [ 6 ] }, 
                   { "bSortable": false, "aTargets": [ 7 ] },
                   { "bSortable": false, "aTargets": [ 8 ] }
                ],
                "aaSorting": [[ 4, "desc" ]]
            } ); 
            $('#delEmp').live('click', function () {
               var id = $(this).attr('val');
               var r = confirm("Are You Sure Delete Employee ?");
               if (r==true){
                  $.ajax({
                     type: "POST",
                     url: "process/processEmpRegister.php",
                     data:{EmpID:id ,type:'salaryDelete'},
                     beforeSend : function () {
                        //$('#wait').html("Wait for checking");
                     },
                     success:function(){
                        oTable.fnDraw();
                        alert("Delete sucessful");
                     }
                  });
               }else{   
               }
            });
            
           
            
            
            });
            function IncrementUpdate(){
                
            }
        </script--->
<!--        end Data tabel-->
        <script>
            window.onload = menuSelect('menuEmployeeList');
        </script>
		<script>
		 new WOW().init();
	</script>
    </head>

    <body>
        <!-- wrap starts here -->
        <div id="wrap">

            <!--header -->
            <?php @require_once 'menu/header.php'; ?>

            <!-- navigation -->	
            <?php @require_once 'menu/menu.php'; ?>

            <!-- content-wrap starts here -->
            <div id="content-wrap">
                <div id="main">				
                    <div class="clear"></div>
            <div>
			  <a href="javascript:window.print()">Print</a> 
            <table class="displayGrid tbl" id="dataList" cellpadding="0" cellspacing="0" border="0" style="table-layout: fixed;" width="700px">
                        <thead>
                            <tr>
                                <th rowspan="2" width="50px">ID</th>
                                <th rowspan="2" width="215px">Name</th>
                                <th rowspan="2" width="215px">Subject</th>
                                <th rowspan="2" width="100px">Class</th>
                                <th rowspan="2" width="90px">Time</th>
								<th rowspan="2" width="90px">Action</th>
                            </tr>
                            </thead>
							<?php		
						
								$con = mysqli_connect("localhost", "root" , "");
							$db =mysqli_select_db($con, "attendance_system");
								
								
								$contri=mysqli_query($con,"select * from employee_detail ");
				if(!$contri){
				echo'hey'.die(mysqli_error());

				}						 
							while($row=mysqli_fetch_array($contri))
				{
						
				     echo "<tr>";
                     echo "<td>". $row['EmpID']." </td>";
                     echo "<td><label class='label label-info'>".$row['EmpName']."</label></td>";
                     echo "<td><label class='label label-info'>".$row['EmpTechnology']."</label></td>";
					 echo "<td><label class='label label-info'>".$row['EmpClass']."</label></td>";
                     echo "<td><label class='label label-info'>".$row['Time']."</label></td>";
					 echo '<td><a href="employee.php?solid='.$row['EmpID'].'"> Action</a></td>';
                     echo "</tr>";
				

				}
				
				?>
							
                        <tbody>	
                        </tbody>
                    </table>
             </div>
                 
                <div class="clear"></div>
                </div>
            
            <!-- content-wrap ends here -->
            </div> 
            <!--footer starts here-->
            <?php @require_once 'menu/footer.php'; ?>
            <!-- wrap ends here -->
        </div>
    </body>
</html>
