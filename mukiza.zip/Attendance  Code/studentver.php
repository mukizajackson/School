<html>
<head>
</head>
<body>

<?php
require_once 'config/config.php';
require_once 'config/session.php';
require_once 'class/dbclass.php';
//$id=$_GET['id'];
// echo"<SCRIPT LANGUAGE='JavaScript'>alert('ID got done".$id."')</script>";

 if(isset($_GET['id']))
{
	$gew = '';
	$id=$_GET['id'];
					$con = mysqli_connect("localhost", "root" , "");
							$db =mysqli_select_db($con,"attendance_system");
$ccus=mysqli_query($con,"select * from student where id = '$id'");
while($row=mysqli_fetch_array($ccus))
{

$gew = $row['name'];
//echo $gew;
}
$staff= '';
$staff = $_SESSION['UserID'];
//echo $staff;
$ccus=mysqli_query($con,"select * from employee_detail where EmpID = '$staff'");
while($row=mysqli_fetch_array($ccus))
{

$a=$row['EmpTechnology'];
$b=$row['EmpClass'];
$c=$row['Time'];

}
					            $id        = $_GET['id'];
					            $names     =$_POST['studentnames'];
								$present   = "present";
								$date      = date('Y-m-d');
								$tea = $_SESSION['UserID'];
								//$a = $_POST['stusubject'];
								//$b= $_POST['stuclass'];
								//$c = $_POST['Stutime'];
							 $qry = "INSERT INTO `attendance_student` (`StuID`,`Names`,`Status`,`date`,`Teacher`) 
							 VALUES('$id','$gew','$present','$date','$tea') ";
							 echo $qry;
							 //$sample = $sql;
							  //echo"<SCRIPT LANGUAGE='JavaScript'>alert('".$sample."')</script>";
							  //echo $sql;
							 $entered = mysqli_query($con, $qry) or die("Data not inserted");
							 if ($entered)
							 {
								 $que="UPDATE `attendance_student` SET `class` ='$b', `subject`='$a', `Time`='$c' WHERE `StuID` ='$id' date = $date";
									//echo $que;
									  $updatequery = mysqli_query($que);
								 echo"<SCRIPT LANGUAGE='JavaScript'>alert('sucessfully done".$sample."')</script>";
								 header("Location:AddAttendanceStudent.php");
							 }
					
					echo"<SCRIPT LANGUAGE='JavaScript'>alert('THis student is present')</script>";
					   
				
}
?>
</body>
</html>