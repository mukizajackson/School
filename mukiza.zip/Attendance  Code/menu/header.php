<div id="header">
    <h1 id="logo-text"><a href=".">St Paul Primary</a></h1>
    <p id="slogan"> School Bbuga</p>
    <div id="header-links">
        <p>
            <a href=".">Home</a> | 
            <a href="AddAttendanceStudent.php">Attandance Student</a> | 
            <a href="EmployeeRegister.php">Employee Register</a>
        </p>
    </div>
</div>