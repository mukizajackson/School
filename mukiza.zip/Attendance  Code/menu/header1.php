<div id="header">
    <h1 id="logo-text"><a href="Teacher.php">St Paul Primary</a></h1>
    <p id="slogan">School Bbuga</p>
    <div id="header-links">
        <p>
              <?php		
			  require_once 'config/config.php';
              require_once 'config/session.php';
					if(isset($_GET['id'])){
						$con = mysql_connect("localhost", "root" , "");
							$db =mysql_select_db("attendance_system");
								$newsatff='';
								$tea = $_SESSION['UserID'];
							$contri=mysql_query("select * from `employee_detail` where EmpID = '$tea'");
							if(!$contri){
							echo'hey'.die(mysql_error());

							}						 
							while($row=mysql_fetch_array($contri))
							{
							$newsatff=$row['EmpID'];
							}
				                         }
				echo $newsatff. 'Logged in sucessfully' ;
				?>
				
			<!--?php echo $newsatff. 'Logged in sucessfully' ;?-->
        </p>
    </div>
</div>