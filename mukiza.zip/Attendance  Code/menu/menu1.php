<div  id="menu">
    <ul>
        <li id="menuHome"><a href="Teacher.php">Home</a></li>
        <li id="menuAttandance" ><a href="AddAttendanceTeacher.php">Staff Attandance</a></li>
		<li id="" ><a href="AddAttendanceStudent1.php">Student Attandance</a></li>
        <li id="menuEmployeeReport" ><a href="EmployeeReportTeacher.php">Emp Report</a></li>
		<li id="menuEmployee" ><a href="stuattendance1.php">Student Report</a></li>
        <li id="menuEmployeeList" ><a href="logout.php">Logout</a></li>
    </ul>
</div>	