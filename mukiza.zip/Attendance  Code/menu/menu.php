<div  id="menu">
    <ul>
        <li id="menuHome"><a href="Admin.php">Home</a></li>
        <li id="menuAttandance" ><a href="AddAttendance.php">Attandance Staff</a></li>
        <li id="menuEmployee" ><a href="EmployeeRegister.php">Register Emp</a></li>
		<li id="menuEmployee" ><a href="StudentRegister.php">Register Student</a></li>
        <li id="menuEmployeeList" ><a href="EmployeeList.php">Emp List</a></li>
        <li id="menuEmployeeReport" ><a href="EmployeeReport.php">Emp Report</a></li>
		 <li id="" ><a href="stuattendance.php">Student Report</a></li>
        <li id="menuEmployeeList" ><a href="logout.php">Logout</a></li>
    </ul>
</div>	