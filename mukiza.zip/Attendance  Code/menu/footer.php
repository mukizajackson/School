<div id="footer">
    <p>
        &copy; 2017 <strong>Email | SPPS@info.com</strong> 
        </p>
</div>
<?php $_SESSION['Msg']=''; ?>